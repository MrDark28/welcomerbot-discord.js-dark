# discord.js-Welcomer

## What does this bot do?
This bot will welcome anybody who join the server based on the code.. It has to be set manually in the code..
But don't worry Just check this **[Video](https://www.youtube.com/watch?v=CW1hEPiBBJc)** out if you need any help reguarding setup of this bot..

## Languages Used
discord.js

## More like this!!
For more awesome bot make sure to Subscribe [The Channel](https://www.youtube.com/channel/UCmTSEzt4h1S4MiCM1grWu9g)
For any other support make sure to join our [Discord Server!!](https://discord.gg/86pEDZy3dp) :D

Thanks for using this bot :D
